package sml;

public interface RegisterName {
    String name();
}
